package com.medsync.app.ad.repository;

public interface CrudRepository<T, T1> {
}
