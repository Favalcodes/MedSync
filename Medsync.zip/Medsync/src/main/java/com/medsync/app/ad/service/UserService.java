package com.medsync.app.ad.service;

import com.medsync.app.ad.shared.dto.UserDto;

public interface UserService {
	
	UserDto createUser(UserDto user);

}
