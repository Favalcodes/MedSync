package com.medsync.app.ad.repository;

public @interface Repository {
}
